---
name: Something else
about: Something's wrong, but it's not a bug with the template
title: ''
labels: ''
assignees: ''

---

<!-- If you're requesting a new feature or suggesting an idea, please use the "Discussions" tab instead of opening a new issue. Thank you! -->
